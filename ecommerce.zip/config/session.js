 const userSession="thisisuser"
 const adminSession="thisisadmin"

 module.exports={userSession,adminSession}
