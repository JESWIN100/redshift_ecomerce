const isLogin = async (req, res, next) => {
    try {
        // Check if the admin is logged in by checking if the session contains 'admin_id'
        if (req.session.admin_id) {
            return next(); // Admin is logged in, proceed to the next route handler
        } else {
            // Admin is not logged in, redirect to the login page
            return res.render('login', { message: 'Please log in to access this page.' });
        }
    } catch (error) {
        console.log('Error in isLogin middleware:', error.message);
        return res.status(500).send('Internal Server Error');
    }
};

const isLogout = async (req, res, next) => {
    try {
        // Check if the admin is already logged in
        if (req.session.admin_id) {
            // Admin is logged in, redirect to the admin dashboard
            return res.redirect('/admin');
        } else {
            // Admin is not logged in, proceed to the login page
            return next(); // Proceed to the login route
        }
    } catch (error) {
        console.log('Error in isLogout middleware:', error.message);
        return res.status(500).send('Internal Server Error');
    }
};

module.exports = { isLogin, isLogout };